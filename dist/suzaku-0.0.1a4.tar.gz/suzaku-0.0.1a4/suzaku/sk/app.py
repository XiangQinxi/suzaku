from ..base.application import Application


class SkApp(Application):

    """
    应用程序，继承自Application
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
